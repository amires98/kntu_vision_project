from torch.utils.data import Dataset
import cv2
import os
from skimage import io


class Customdataloader(Dataset):

  def __init__(self,info,root_dir,transform=None):
    self.info=info
    self.root_dir=root_dir
    self.transform=transform

  def __len__(self):
    return len(self.info)

  def __getitem__(self,index):

    residual=str(index)+'.jpg'
    img_path=os.path.join(self.root_dir,residual)
    img=io.imread(img_path)
    str_label=self.info[index][0]

    y_label=0
    if str_label == 'b':
      y_label=1
    elif str_label == 'ref':
      y_label=2

    if self.transform:
      img=self.transform(img)
    
    return (img, y_label)